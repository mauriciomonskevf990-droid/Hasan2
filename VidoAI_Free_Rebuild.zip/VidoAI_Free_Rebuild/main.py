import os
import uuid
import json
import shutil
import subprocess
import threading
from pathlib import Path
from datetime import datetime, timezone
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles

APP_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.getenv("DATA_DIR", str(APP_DIR / "data")))
UPLOAD_DIR = DATA_DIR / "uploads"
OUTPUT_DIR = DATA_DIR / "outputs"
for folder in (DATA_DIR, UPLOAD_DIR, OUTPUT_DIR):
    folder.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="VidoAI Free Studio")
app.mount("/static", StaticFiles(directory=APP_DIR / "static"), name="static")

jobs = {}
jobs_lock = threading.Lock()
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "200"))
MAX_IMAGES = 40
MAX_AUDIO = 1
MAX_DURATION_MINUTES = 60
MAX_DURATION_SECONDS = MAX_DURATION_MINUTES * 60


def public_job(job):
    return {k: v for k, v in job.items() if k not in ("work_dir", "output_path")}


def ffmpeg_available():
    return shutil.which("ffmpeg") is not None


def run_ffmpeg(args):
    proc = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if proc.returncode != 0:
        raise RuntimeError((proc.stderr or "FFmpeg failed")[-1600:])


def create_video(job_id, image_paths, audio_path, script, minutes, output_path):
    job = jobs[job_id]
    work_dir = Path(job["work_dir"])
    try:
        if not ffmpeg_available():
            raise RuntimeError("На сервере не найден FFmpeg. Используйте Docker-развёртывание из проекта.")
        job["status"] = "processing"
        job["progress"] = 5
        job["message"] = "Подготовка фотографий"

        # Split the full duration into small image scenes. No paid AI API is called.
        total_seconds = int(minutes * 60)
        count = max(1, len(image_paths))
        seconds_per_image = total_seconds / count
        scene_files = []
        for idx, img in enumerate(image_paths):
            scene_path = work_dir / f"scene_{idx:03d}.mp4"
            # Ken Burns-like slow zoom/pan; output 1080p at 25 fps.
            # Escape paths for ffmpeg filter syntax.
            vf = (
                "scale=1920:1080:force_original_aspect_ratio=increase,"
                "crop=1920:1080,"
                "zoompan=z='min(zoom+0.00035,1.08)':"
                "x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':"
                "d=1:s=1920x1080:fps=25,"
                "setsar=1,format=yuv420p"
            )
            duration = seconds_per_image
            args = [
                "ffmpeg", "-y", "-loop", "1", "-i", str(img),
                "-t", f"{duration:.4f}", "-vf", vf,
                "-r", "25", "-an", "-c:v", "libx264", "-preset", "ultrafast",
                "-crf", "28", "-pix_fmt", "yuv420p", str(scene_path)
            ]
            run_ffmpeg(args)
            scene_files.append(scene_path)
            job["progress"] = min(70, 5 + int(65 * (idx + 1) / count))
            job["message"] = f"Создание сцены {idx + 1} из {count}"

        job["message"] = "Сборка видео"
        job["progress"] = 75
        concat_file = work_dir / "concat.txt"
        with concat_file.open("w", encoding="utf-8") as f:
            for p in scene_files:
                f.write("file '" + str(p).replace("'", "'\\''") + "'\n")

        # Concat filter avoids stream-copy mismatches and adds optional audio.
        silent_path = work_dir / "joined_silent.mp4"
        run_ffmpeg([
            "ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat_file),
            "-t", str(total_seconds), "-c:v", "libx264", "-preset", "ultrafast",
            "-crf", "28", "-pix_fmt", "yuv420p", "-an", str(silent_path)
        ])
        job["progress"] = 88
        job["message"] = "Добавление музыки и финальная обработка"
        if audio_path:
            # Loop music to cover full video and fade it out at the end.
            run_ffmpeg([
                "ffmpeg", "-y", "-i", str(silent_path), "-stream_loop", "-1", "-i", str(audio_path),
                "-t", str(total_seconds), "-map", "0:v:0", "-map", "1:a:0",
                "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
                "-af", "afade=t=out:st=" + str(max(0, total_seconds - 3)) + ":d=3",
                "-shortest", "-movflags", "+faststart", str(output_path)
            ])
        else:
            shutil.copy2(silent_path, output_path)

        job["status"] = "completed"
        job["progress"] = 100
        job["message"] = "Видео готово"
        job["output_path"] = str(output_path)
    except Exception as e:
        job["status"] = "failed"
        job["message"] = str(e)[:1800]


@app.get("/", response_class=HTMLResponse)
def home():
    return (APP_DIR / "static" / "index.html").read_text(encoding="utf-8")


@app.get("/api/health")
def health():
    return {"ok": True, "ffmpeg": ffmpeg_available(), "mode": "free-photo-video"}


@app.post("/api/jobs")
async def make_job(
    images: list[UploadFile] = File(...),
    minutes: int = Form(...),
    script: str = Form(""),
    music: UploadFile | None = File(None),
):
    if not ffmpeg_available():
        raise HTTPException(503, "FFmpeg не установлен на сервере.")
    if not 1 <= len(images) <= MAX_IMAGES:
        raise HTTPException(400, f"Загрузите от 1 до {MAX_IMAGES} фотографий.")
    if not 1 <= minutes <= MAX_DURATION_MINUTES:
        raise HTTPException(400, "Длительность должна быть от 1 до 60 минут.")
    job_id = uuid.uuid4().hex[:12]
    work_dir = DATA_DIR / "work" / job_id
    work_dir.mkdir(parents=True, exist_ok=True)
    image_paths = []
    total_bytes = 0
    allowed_images = {".jpg", ".jpeg", ".png", ".webp"}
    for i, upload in enumerate(images):
        suffix = Path(upload.filename or "").suffix.lower()
        if suffix not in allowed_images:
            raise HTTPException(400, "Фотографии должны быть JPG, JPEG, PNG или WEBP.")
        content = await upload.read()
        total_bytes += len(content)
        if total_bytes > MAX_UPLOAD_MB * 1024 * 1024:
            raise HTTPException(413, f"Общий размер загрузки превышает {MAX_UPLOAD_MB} МБ.")
        path = work_dir / f"image_{i:03d}{suffix}"
        path.write_bytes(content)
        image_paths.append(path)

    audio_path = None
    if music and music.filename:
        audio_suffix = Path(music.filename).suffix.lower()
        if audio_suffix not in {".mp3", ".wav", ".m4a", ".aac", ".ogg"}:
            raise HTTPException(400, "Музыка должна быть MP3, WAV, M4A, AAC или OGG.")
        content = await music.read()
        total_bytes += len(content)
        if total_bytes > MAX_UPLOAD_MB * 1024 * 1024:
            raise HTTPException(413, f"Общий размер загрузки превышает {MAX_UPLOAD_MB} МБ.")
        audio_path = work_dir / f"music{audio_suffix}"
        audio_path.write_bytes(content)

    output_path = OUTPUT_DIR / f"vidoai_{job_id}.mp4"
    job = {
        "id": job_id, "status": "queued", "progress": 0,
        "message": "Задание создано", "minutes": minutes,
        "script": script[:10000], "created_at": datetime.now(timezone.utc).isoformat(),
        "work_dir": str(work_dir), "output_path": str(output_path),
    }
    with jobs_lock:
        jobs[job_id] = job
    thread = threading.Thread(
        target=create_video,
        args=(job_id, image_paths, audio_path, script, minutes, output_path),
        daemon=True,
    )
    thread.start()
    return {"id": job_id, "status": "queued"}


@app.get("/api/jobs/{job_id}")
def job_status(job_id: str):
    job = jobs.get(job_id)
    if not job:
        raise HTTPException(404, "Задание не найдено. Если сервер перезапускался, запустите создание заново.")
    return public_job(job)


@app.get("/api/jobs/{job_id}/download")
def download(job_id: str):
    job = jobs.get(job_id)
    if not job or job.get("status") != "completed":
        raise HTTPException(409, "Видео ещё не готово.")
    path = Path(job["output_path"])
    if not path.exists():
        raise HTTPException(404, "Файл видео не найден.")
    return FileResponse(path, media_type="video/mp4", filename=f"vidoai_{job_id}.mp4")
